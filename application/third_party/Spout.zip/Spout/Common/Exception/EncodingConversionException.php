<?php

namespace Box\Spout\Common\Exception;

/**
 * Class EncodingConversionException
 *
 * @api
 * @package Box\Spout\Common\Exception
 */
class EncodingConversionException extends SpoutException
{
}
